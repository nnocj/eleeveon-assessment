import {
  db,
  type IdentityCredential,
  type IdentityCredentialStatus,
} from "../db/db";
import type {
  IdentityCredentialType,
  IdentityMutationContext,
  IdentitySubjectType,
} from "./types";
import { appendCredentialEvent } from "./credential-events";
import { newSyncRecord, touchSyncRecord } from "./exports";
import { assertValid, validateCredential } from "./validation";

export interface CreateCredentialInput {
  subjectType: IdentitySubjectType;
  subjectId: string;
  credentialType: IdentityCredentialType;
  label?: string | null;
  credentialReference?: string | null;
  tokenHash?: string | null;
  serialNumber?: string | null;
  provider?: string | null;
  providerCredentialId?: string | null;
  validFrom?: number | null;
  expiresAt?: number | null;
  status?: IdentityCredentialStatus;
  metadata?: Record<string, unknown>;
}

export async function createCredential(
  context: IdentityMutationContext,
  input: CreateCredentialInput,
): Promise<IdentityCredential> {
  const now = context.now ?? Date.now();
  const credential: IdentityCredential = {
    ...newSyncRecord({ ...context, now }),
    schoolId: context.schoolId,
    branchId: context.branchId ?? null,
    subjectType: input.subjectType,
    subjectId: input.subjectId,
    credentialType: input.credentialType,
    status: input.status ?? "pending",
    label: input.label ?? null,
    credentialReference: input.credentialReference ?? null,
    tokenHash: input.tokenHash ?? null,
    serialNumber: input.serialNumber ?? null,
    provider: input.provider ?? null,
    providerCredentialId: input.providerCredentialId ?? null,
    validFrom: input.validFrom ?? now,
    expiresAt: input.expiresAt ?? null,
    generatedAt: now,
    generatedByUserId: context.userId ?? null,
    usageCount: 0,
    metadata: input.metadata,
  };

  assertValid(validateCredential(credential));
  await db.identityCredentials.add(credential);

  await appendCredentialEvent(context, {
    credentialId: credential.id,
    subjectType: credential.subjectType,
    subjectId: credential.subjectId,
    eventType: "generated",
    occurredAt: now,
  });

  return credential;
}

export async function findCredentialByReference(
  reference: string,
): Promise<IdentityCredential | undefined> {
  return db.identityCredentials
    .where("credentialReference")
    .equals(reference)
    .first();
}

export async function listSubjectCredentials(
  subjectType: IdentitySubjectType,
  subjectId: string,
): Promise<IdentityCredential[]> {
  const credentials = await db.identityCredentials
    .where("subjectId")
    .equals(subjectId)
    .toArray();

  return credentials.filter(
    (item) => item.subjectType === subjectType && !item.isDeleted,
  );
}

async function transitionCredential(
  context: IdentityMutationContext,
  credentialId: string,
  status: IdentityCredentialStatus,
  eventType:
    | "activated"
    | "suspended"
    | "reactivated"
    | "revoked"
    | "expired"
    | "replaced",
  reason?: string | null,
): Promise<IdentityCredential> {
  const current = await db.identityCredentials.get(credentialId);
  if (!current || current.isDeleted) {
    throw new Error("Identity credential was not found.");
  }

  const now = context.now ?? Date.now();
  const patch: Partial<IdentityCredential> = {
    status,
    ...touchSyncRecord(current, context),
  };

  if (status === "active") {
    patch.activatedAt = now;
    patch.activatedByUserId = context.userId ?? null;
    patch.suspendedAt = null;
    patch.suspendedByUserId = null;
    patch.suspensionReason = null;
  } else if (status === "suspended") {
    patch.suspendedAt = now;
    patch.suspendedByUserId = context.userId ?? null;
    patch.suspensionReason = reason ?? null;
  } else if (status === "revoked") {
    patch.revokedAt = now;
    patch.revokedByUserId = context.userId ?? null;
    patch.revocationReason = reason ?? null;
  } else if (status === "expired") {
    patch.expiresAt = current.expiresAt ?? now;
  } else if (status === "replaced") {
    patch.replacedAt = now;
  }

  await db.identityCredentials.update(credentialId, patch);
  await appendCredentialEvent(context, {
    credentialId,
    subjectType: current.subjectType,
    subjectId: current.subjectId,
    eventType,
    reasonCode: reason ?? null,
    occurredAt: now,
  });

  return { ...current, ...patch } as IdentityCredential;
}

export const activateCredential = (
  context: IdentityMutationContext,
  credentialId: string,
) => transitionCredential(context, credentialId, "active", "activated");

export const suspendCredential = (
  context: IdentityMutationContext,
  credentialId: string,
  reason?: string | null,
) => transitionCredential(
  context,
  credentialId,
  "suspended",
  "suspended",
  reason,
);

export const reactivateCredential = (
  context: IdentityMutationContext,
  credentialId: string,
) => transitionCredential(
  context,
  credentialId,
  "active",
  "reactivated",
);

export const revokeCredential = (
  context: IdentityMutationContext,
  credentialId: string,
  reason?: string | null,
) => transitionCredential(
  context,
  credentialId,
  "revoked",
  "revoked",
  reason,
);

export const expireCredential = (
  context: IdentityMutationContext,
  credentialId: string,
) => transitionCredential(
  context,
  credentialId,
  "expired",
  "expired",
);

export async function markCredentialUsed(
  context: IdentityMutationContext,
  credentialId: string,
): Promise<void> {
  const current = await db.identityCredentials.get(credentialId);
  if (!current) return;

  await db.identityCredentials.update(credentialId, {
    lastUsedAt: context.now ?? Date.now(),
    usageCount: (current.usageCount ?? 0) + 1,
    ...touchSyncRecord(current, context),
  });
}
