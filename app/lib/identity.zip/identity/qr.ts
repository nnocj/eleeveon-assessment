import {
  IDENTITY_QR_VERSION,
  IDENTITY_TOKEN_PREFIX,
} from "./constants";

export interface IdentityQrPayload {
  version: number;
  credentialId: string;
  reference: string;
  issuedAt: number;
  expiresAt?: number | null;
  nonce?: string;
}

function encodeBase64Url(value: string): string {
  if (typeof btoa === "function") {
    return btoa(unescape(encodeURIComponent(value)))
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/g, "");
  }

  const BufferCtor = (globalThis as unknown as {
    Buffer?: { from(input: string, encoding?: string): { toString(encoding: string): string } };
  }).Buffer;

  if (!BufferCtor) throw new Error("Base64 encoding is unavailable.");
  return BufferCtor.from(value, "utf8")
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function decodeBase64Url(value: string): string {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized + "=".repeat((4 - normalized.length % 4) % 4);

  if (typeof atob === "function") {
    return decodeURIComponent(escape(atob(padded)));
  }

  const BufferCtor = (globalThis as unknown as {
    Buffer?: { from(input: string, encoding?: string): { toString(encoding: string): string } };
  }).Buffer;

  if (!BufferCtor) throw new Error("Base64 decoding is unavailable.");
  return BufferCtor.from(padded, "base64").toString("utf8");
}

export function buildIdentityQrValue(
  payload: Omit<IdentityQrPayload, "version"> &
    Partial<Pick<IdentityQrPayload, "version">>,
): string {
  const body: IdentityQrPayload = {
    ...payload,
    version: payload.version ?? IDENTITY_QR_VERSION,
  };

  return `${IDENTITY_TOKEN_PREFIX}.${encodeBase64Url(JSON.stringify(body))}`;
}

export function parseIdentityQrValue(
  rawValue: string,
): IdentityQrPayload | null {
  const [prefix, encoded] = rawValue.trim().split(".", 2);
  if (prefix !== IDENTITY_TOKEN_PREFIX || !encoded) return null;

  try {
    const payload = JSON.parse(decodeBase64Url(encoded)) as IdentityQrPayload;

    if (
      payload.version !== IDENTITY_QR_VERSION ||
      !payload.credentialId ||
      !payload.reference ||
      !Number.isFinite(payload.issuedAt)
    ) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

export function isQrPayloadExpired(
  payload: IdentityQrPayload,
  now = Date.now(),
): boolean {
  return payload.expiresAt != null && payload.expiresAt <= now;
}
