"use client";

/**
 * app/lib/websites/builder/settings/WebsiteSettingsSheet.tsx
 * --------------------------------------------------------------------------
 * Report-style website settings experience:
 * - template selection;
 * - exact shared preview;
 * - display, labels, content and ordering controls;
 * - domain, SEO and publishing;
 * - local-first persistence for identity, template settings and assignment.
 */

import React, {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  db,
  type WebsiteTemplateAssignment,
  type WebsiteTemplateSetting,
} from "../../../db/db";

import { SyncStatus } from "../../../constants/syncStatus";

import type {
  WebsiteEditorTab,
  WebsiteSettingsDraft,
  WebsiteTemplateSettings,
  WebsiteTemplateDefinition,
  WebsiteStatus,
} from "../../types";

import {
  applyWebsiteTemplateDesign,
  createWebsiteTemplateSettings,
} from "../../shared/websiteTemplateSettings";

import {
  normalizeCustomDomain,
  splitKeywords,
  websiteSettingsDraft,
} from "../../shared/websiteDefaults";

import {
  getDefaultWebsiteTemplate,
  getWebsiteTemplate,
  getWebsiteTemplates,
} from "../../templates/registry";

import WebsitePreview from "../../components/WebsitePreview";
import WebsiteTemplateSelector from "./WebsiteTemplateSelector";
import WebsiteDisplayControls from "./WebsiteDisplayControls";
import WebsiteLabelControls from "./WebsiteLabelControls";
import WebsiteContentOverrides from "./WebsiteContentOverrides";
import WebsiteSectionOrder from "./WebsiteSectionOrder";
import WebsitePublishingControls from "./WebsitePublishingControls";
import WebsiteDomainControls from "./WebsiteDomainControls";

type AnyRow = Record<string, any>;

const TABS: Array<{
  key: WebsiteEditorTab;
  label: string;
}> = [
  { key: "template", label: "Template" },
  { key: "display", label: "Display" },
  { key: "labels", label: "Labels" },
  { key: "content", label: "Content" },
  { key: "order", label: "Order" },
  { key: "domain", label: "Domain" },
  { key: "seo", label: "SEO" },
  { key: "publishing", label: "Publishing" },
];

const id = () =>
  typeof crypto !== "undefined" &&
  "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random()
        .toString(36)
        .slice(2)}`;

export type WebsiteSettingsSheetProps = {
  open: boolean;
  accountId: string;
  schoolId: string;
  branchId?: string | null;
  schoolName?: string;
  branchName?: string;
  rootDomain?: string;
  onClose: () => void;
  onSaved?: () => void;
};

export default function WebsiteSettingsSheet({
  open,
  accountId,
  schoolId,
  branchId,
  schoolName,
  branchName,
  rootDomain = "eleeveon.com",
  onClose,
  onSaved,
}: WebsiteSettingsSheetProps) {
  const templates = useMemo(
    () => getWebsiteTemplates(),
    [],
  );

  const fallbackTemplate =
    getDefaultWebsiteTemplate();

  const [tab, setTab] =
    useState<WebsiteEditorTab>("template");

  const [draft, setDraft] =
    useState<WebsiteSettingsDraft>(() =>
      websiteSettingsDraft({
        schoolName,
        branchName,
        defaultTemplateKey:
          fallbackTemplate?.key,
      }),
    );

  const [settings, setSettings] =
    useState<WebsiteTemplateSettings>(() =>
      createWebsiteTemplateSettings(
        undefined,
        fallbackTemplate,
      ),
    );

  const [customDomain, setCustomDomain] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const [saving, setSaving] =
    useState(false);

  const [message, setMessage] =
    useState<string | null>(null);

  const selectedTemplate =
    getWebsiteTemplate(
      settings.templateKey ||
        draft.templateKey,
    ) || fallbackTemplate;

  useEffect(() => {
    if (!open) return;

    let cancelled = false;

    setLoading(true);
    setMessage(null);

    Promise.all([
      db.websiteSettings
        .where("schoolId")
        .equals(schoolId)
        .toArray(),
      db.websiteTemplateSettings
        .where("schoolId")
        .equals(schoolId)
        .toArray(),
      db.websiteTemplateAssignments
        .where("schoolId")
        .equals(schoolId)
        .toArray(),
      db.websiteDomains
        .where("schoolId")
        .equals(schoolId)
        .toArray(),
    ])
      .then(
        ([
          websiteRows,
          templateSettingRows,
          assignmentRows,
          domainRows,
        ]) => {
          if (cancelled) return;

          const website = (
            websiteRows as AnyRow[]
          ).find(
            (row) =>
              !row.isDeleted &&
              (!branchId ||
                !row.branchId ||
                row.branchId === branchId),
          );

          const websiteId =
            website?.id;

          const assignment = (
            assignmentRows as AnyRow[]
          ).find(
            (row) =>
              !row.isDeleted &&
              row.active !== false &&
              row.isDefault !== false &&
              (!websiteId ||
                row.websiteSettingId ===
                  websiteId),
          );

          const savedTemplateSetting = (
            templateSettingRows as AnyRow[]
          ).find(
            (row) =>
              !row.isDeleted &&
              row.active !== false &&
              (
                row.id ===
                  assignment?.templateSettingId ||
                row.websiteSettingId ===
                  websiteId
              ),
          );

          const nextDraft =
            websiteSettingsDraft({
              ...website,
              id: websiteId,
              schoolName,
              branchName,
              seoKeywordsText:
                Array.isArray(
                  website?.seoKeywords,
                )
                  ? website.seoKeywords.join(
                      ", ",
                    )
                  : website
                      ?.seoKeywordsText || "",
            });

          const template =
            getWebsiteTemplate(
              savedTemplateSetting
                ?.templateKey ||
                website?.templateKey ||
                nextDraft.templateKey,
            ) || fallbackTemplate;

          const nextSettings =
            createWebsiteTemplateSettings(
              savedTemplateSetting?.settings ||
                website
                  ?.templateSettings,
              template,
            );

          const domain = (
            domainRows as AnyRow[]
          ).find(
            (row) =>
              !row.isDeleted &&
              row.domainType === "custom" &&
              (!websiteId ||
                row.websiteSettingId ===
                  websiteId),
          );

          setDraft(nextDraft);
          setSettings(nextSettings);
          setCustomDomain(
            domain?.hostname || "",
          );
          setLoading(false);
        },
      )
      .catch((error: unknown) => {
        if (cancelled) return;

        setMessage(
          error instanceof Error
            ? error.message
            : "Unable to load website settings.",
        );
        setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [
    open,
    schoolId,
    branchId,
    schoolName,
    branchName,
    fallbackTemplate,
  ]);

  const patchSettings = useCallback(
    <K extends keyof WebsiteTemplateSettings>(
      key: K,
      value: WebsiteTemplateSettings[K],
    ) => {
      setSettings((current) => ({
        ...current,
        [key]: value,
      }));
    },
    [],
  );

  const selectTemplate = (
    template: WebsiteTemplateDefinition,
  ) => {
    setSettings((current) =>
      applyWebsiteTemplateDesign(
        current,
        template,
      ),
    );

    setDraft((current) => ({
      ...current,
      templateKey: template.key,
    }));
  };

  const save = async () => {
    if (!draft.siteName.trim()) {
      setMessage(
        "Enter a website name before saving.",
      );
      return;
    }

    if (!draft.eleeveonSlug.trim()) {
      setMessage(
        "Enter an Eleeveon subdomain before saving.",
      );
      return;
    }

    setSaving(true);
    setMessage(null);

    try {
      const now = Date.now();
      const deviceId =
        localStorage.getItem(
          "eleeveon_device_id",
        ) ||
        localStorage.getItem(
          "deviceId",
        ) ||
        "browser";

      const websiteId =
        draft.id || id();

      const existingWebsite =
        draft.id
          ? await db.websiteSettings.get(
              draft.id,
            )
          : undefined;

      const websiteRecord = {
        ...(existingWebsite || {}),
        id: websiteId,
        accountId,
        schoolId,
        branchId: branchId || null,

        siteName: draft.siteName.trim(),
        tagline:
          draft.tagline.trim() || null,
        description:
          draft.description.trim() || null,

        templateKey:
          settings.templateKey,
        templateVersion:
          settings.templateVersion,

        eleeveonSlug:
          draft.eleeveonSlug.trim(),

        status: draft.status,
        defaultLanguage:
          draft.defaultLanguage || "en",
        searchEngineIndexing:
          draft.searchEngineIndexing,

        seoTitle:
          draft.seoTitle.trim() || null,
        seoDescription:
          draft.seoDescription.trim() ||
          null,
        seoKeywords: splitKeywords(
          draft.seoKeywordsText,
        ),

        analyticsProvider:
          draft.analyticsProvider.trim() ||
          null,
        analyticsTrackingId:
          draft.analyticsTrackingId.trim() ||
          null,

        publishedAt:
          draft.status === "published"
            ? existingWebsite?.publishedAt ||
              now
            : existingWebsite?.publishedAt ||
              null,

        active: true,
        createdAt:
          existingWebsite?.createdAt || now,
        updatedAt: now,
        version:
          Number(
            existingWebsite?.version || 0,
          ) + 1,
        deviceId,
        createdByDeviceId:
          existingWebsite
            ?.createdByDeviceId ||
          deviceId,
        updatedByDeviceId: deviceId,
        synced: SyncStatus.PENDING,
        isDeleted: false,
      };

      await db.websiteSettings.put(
        websiteRecord as any,
      );

      const existingTemplateSettings =
        await db.websiteTemplateSettings
          .where("websiteSettingId")
          .equals(websiteId)
          .toArray();

      const currentTemplateSetting =
        existingTemplateSettings.find(
          (row) =>
            !row.isDeleted &&
            row.active !== false,
        );

      const templateSettingId =
        currentTemplateSetting?.id ||
        id();

      const templateSettingRecord: WebsiteTemplateSetting =
        {
          ...(currentTemplateSetting || {}),
          id: templateSettingId,
          accountId,
          schoolId,
          branchId: branchId || null,
          websiteSettingId: websiteId,
          templateKey:
            settings.templateKey,
          templateVersion:
            settings.templateVersion,
          settings,
          active: true,
          createdAt:
            currentTemplateSetting
              ?.createdAt || now,
          updatedAt: now,
          version:
            Number(
              currentTemplateSetting
                ?.version || 0,
            ) + 1,
          deviceId,
          createdByDeviceId:
            currentTemplateSetting
              ?.createdByDeviceId ||
            deviceId,
          updatedByDeviceId:
            deviceId,
          synced: SyncStatus.PENDING,
          isDeleted: false,
        };

      await db.websiteTemplateSettings.put(
        templateSettingRecord,
      );

      const existingAssignments =
        await db.websiteTemplateAssignments
          .where("websiteSettingId")
          .equals(websiteId)
          .toArray();

      const currentAssignment =
        existingAssignments.find(
          (row) =>
            !row.isDeleted &&
            row.scopeType ===
              "website" &&
            row.active !== false,
        );

      const assignmentRecord: WebsiteTemplateAssignment =
        {
          ...(currentAssignment || {}),
          id:
            currentAssignment?.id ||
            id(),
          accountId,
          schoolId,
          branchId: branchId || null,
          websiteSettingId: websiteId,
          templateSettingId,
          scopeType: "website",
          scopeId: websiteId,
          isDefault: true,
          active: true,
          createdAt:
            currentAssignment
              ?.createdAt || now,
          updatedAt: now,
          version:
            Number(
              currentAssignment?.version ||
                0,
            ) + 1,
          deviceId,
          createdByDeviceId:
            currentAssignment
              ?.createdByDeviceId ||
            deviceId,
          updatedByDeviceId:
            deviceId,
          synced: SyncStatus.PENDING,
          isDeleted: false,
        };

      await db.websiteTemplateAssignments.put(
        assignmentRecord,
      );

      const existingDomains =
        await db.websiteDomains
          .where("websiteSettingId")
          .equals(websiteId)
          .toArray();

      const subdomain =
        existingDomains.find(
          (row: AnyRow) =>
            row.domainType ===
            "eleeveon_subdomain",
        );

      await db.websiteDomains.put({
        ...(subdomain || {}),
        id: subdomain?.id || id(),
        accountId,
        schoolId,
        branchId: branchId || null,
        websiteSettingId: websiteId,
        domainType:
          "eleeveon_subdomain",
        hostname: `${draft.eleeveonSlug}.${rootDomain}`,
        status: "active",
        sslStatus: "active",
        isPrimary: !customDomain,
        active: true,
        createdAt:
          subdomain?.createdAt || now,
        updatedAt: now,
        version:
          Number(subdomain?.version || 0) +
          1,
        deviceId,
        createdByDeviceId:
          subdomain?.createdByDeviceId ||
          deviceId,
        updatedByDeviceId: deviceId,
        synced: SyncStatus.PENDING,
        isDeleted: false,
      } as any);

      const normalizedDomain =
        normalizeCustomDomain(
          customDomain,
        );

      const savedCustomDomain =
        existingDomains.find(
          (row: AnyRow) =>
            row.domainType === "custom",
        );

      if (normalizedDomain) {
        await db.websiteDomains.put({
          ...(savedCustomDomain || {}),
          id:
            savedCustomDomain?.id || id(),
          accountId,
          schoolId,
          branchId: branchId || null,
          websiteSettingId: websiteId,
          domainType: "custom",
          hostname: normalizedDomain,
          status:
            savedCustomDomain?.status ||
            "pending",
          sslStatus:
            savedCustomDomain?.sslStatus ||
            "pending",
          isPrimary: true,
          active: true,
          createdAt:
            savedCustomDomain?.createdAt ||
            now,
          updatedAt: now,
          version:
            Number(
              savedCustomDomain?.version ||
                0,
            ) + 1,
          deviceId,
          createdByDeviceId:
            savedCustomDomain
              ?.createdByDeviceId ||
            deviceId,
          updatedByDeviceId: deviceId,
          synced: SyncStatus.PENDING,
          isDeleted: false,
        } as any);
      } else if (savedCustomDomain) {
        await db.websiteDomains.put({
          ...savedCustomDomain,
          active: false,
          isDeleted: true,
          updatedAt: now,
          version:
            Number(
              savedCustomDomain.version ||
                0,
            ) + 1,
          updatedByDeviceId: deviceId,
          synced: SyncStatus.PENDING,
        } as any);
      }

      setDraft((current) => ({
        ...current,
        id: websiteId,
      }));

      setMessage(
        draft.status === "published"
          ? "Website settings saved and published."
          : "Website settings saved.",
      );

      onSaved?.();
    } catch (error: unknown) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to save website settings.",
      );
    } finally {
      setSaving(false);
    }
  };

  if (!open) return null;

  return (
    <div
      className="website-settings-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Website settings"
    >
      <div className="website-settings-sheet">
        <header className="website-settings-header">
          <div>
            <strong>School Website</strong>
            <small>
              Configure the real public website.
            </small>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close website settings"
          >
            ×
          </button>
        </header>

        <div className="website-settings-body">
          <aside className="website-settings-controls">
            <nav className="website-settings-tabs">
              {TABS.map((item) => (
                <button
                  key={item.key}
                  type="button"
                  className={
                    tab === item.key
                      ? "is-active"
                      : ""
                  }
                  onClick={() =>
                    setTab(item.key)
                  }
                >
                  {item.label}
                </button>
              ))}
            </nav>

            <div className="website-settings-panel">
              {loading ? (
                <div role="status">
                  Loading website settings…
                </div>
              ) : null}

              {!loading &&
              tab === "template" ? (
                <WebsiteTemplateSelector
                  templates={templates}
                  selectedKey={
                    selectedTemplate?.key ||
                    settings.templateKey
                  }
                  settings={settings}
                  disabled={saving}
                  onSelect={selectTemplate}
                />
              ) : null}

              {!loading &&
              tab === "display" ? (
                <WebsiteDisplayControls
                  settings={settings}
                  disabled={saving}
                  onChange={patchSettings}
                />
              ) : null}

              {!loading &&
              tab === "labels" ? (
                <WebsiteLabelControls
                  settings={settings}
                  disabled={saving}
                  onChange={patchSettings}
                />
              ) : null}

              {!loading &&
              tab === "content" ? (
                <WebsiteContentOverrides
                  settings={settings}
                  disabled={saving}
                  onChange={patchSettings}
                />
              ) : null}

              {!loading &&
              tab === "order" ? (
                <WebsiteSectionOrder
                  settings={settings}
                  disabled={saving}
                  onChange={(sectionOrder) =>
                    patchSettings(
                      "sectionOrder",
                      sectionOrder,
                    )
                  }
                />
              ) : null}

              {!loading &&
              tab === "domain" ? (
                <WebsiteDomainControls
                  slug={draft.eleeveonSlug}
                  customDomain={customDomain}
                  rootDomain={rootDomain}
                  disabled={saving}
                  onSlugChange={(value) =>
                    setDraft((current) => ({
                      ...current,
                      eleeveonSlug: value,
                    }))
                  }
                  onCustomDomainChange={
                    setCustomDomain
                  }
                />
              ) : null}

              {!loading &&
              tab === "seo" ? (
                <div className="website-settings-form-grid">
                  <label className="website-settings-field">
                    <span>SEO title</span>
                    <input
                      value={draft.seoTitle}
                      disabled={saving}
                      onChange={(event) =>
                        setDraft((current) => ({
                          ...current,
                          seoTitle:
                            event.target.value,
                        }))
                      }
                    />
                  </label>

                  <label className="website-settings-field website-settings-field-wide">
                    <span>SEO description</span>
                    <textarea
                      value={
                        draft.seoDescription
                      }
                      disabled={saving}
                      rows={4}
                      onChange={(event) =>
                        setDraft((current) => ({
                          ...current,
                          seoDescription:
                            event.target.value,
                        }))
                      }
                    />
                  </label>

                  <label className="website-settings-field website-settings-field-wide">
                    <span>SEO keywords</span>
                    <input
                      value={
                        draft.seoKeywordsText
                      }
                      disabled={saving}
                      placeholder="school, admissions, Accra"
                      onChange={(event) =>
                        setDraft((current) => ({
                          ...current,
                          seoKeywordsText:
                            event.target.value,
                        }))
                      }
                    />
                  </label>
                </div>
              ) : null}

              {!loading &&
              tab === "publishing" ? (
                <WebsitePublishingControls
                  draft={draft}
                  disabled={saving}
                  onStatusChange={(
                    status: WebsiteStatus,
                  ) =>
                    setDraft((current) => ({
                      ...current,
                      status,
                    }))
                  }
                  onIndexingChange={(value) =>
                    setDraft((current) => ({
                      ...current,
                      searchEngineIndexing:
                        value,
                    }))
                  }
                />
              ) : null}
            </div>
          </aside>

          <main className="website-settings-preview">
            <div className="website-settings-preview-head">
              <div>
                <strong>Live Preview</strong>
                <small>
                  Uses the real website renderer.
                </small>
              </div>

              <span>
                {selectedTemplate?.name ||
                  "Template"}
              </span>
            </div>

            <WebsitePreview
              accountId={accountId}
              schoolId={schoolId}
              branchId={branchId}
              websiteSettingId={draft.id}
              draft={draft}
              settings={settings}
            />
          </main>
        </div>

        <footer className="website-settings-footer">
          <span>
            {message || "Changes are saved locally first and synced automatically."}
          </span>

          <div>
            <button
              type="button"
              onClick={onClose}
              disabled={saving}
            >
              Close
            </button>

            <button
              type="button"
              onClick={save}
              disabled={saving || loading}
            >
              {saving
                ? "Saving…"
                : draft.status ===
                    "published"
                  ? "Save & Publish"
                  : "Save Settings"}
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
}
