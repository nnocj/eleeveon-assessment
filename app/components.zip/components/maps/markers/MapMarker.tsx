"use client";

import type { ReactNode } from "react";
import type {
  MapMarker as MapMarkerData,
} from "../../../lib/maps";
import type {
  MapCanvasChildProps,
} from "../core/MapCanvas";

export interface MapMarkerProps extends MapCanvasChildProps {
  marker: MapMarkerData;
  selected?: boolean;
  size?: number;
  onClick?: (marker: MapMarkerData) => void;
  renderIcon?: (
    marker: MapMarkerData,
  ) => ReactNode;
}

function statusColor(status?: string): string {
  const value = String(status ?? "").toLowerCase();
  if (
    value.includes("critical") ||
    value.includes("absent") ||
    value.includes("failed") ||
    value.includes("denied")
  ) {
    return "var(--danger, #dc2626)";
  }
  if (
    value.includes("warning") ||
    value.includes("late") ||
    value.includes("risk")
  ) {
    return "var(--warning, #d97706)";
  }
  if (
    value.includes("active") ||
    value.includes("present") ||
    value.includes("success") ||
    value.includes("verified")
  ) {
    return "var(--success, #16a34a)";
  }
  return "var(--primary, #2563eb)";
}

export function MapMarker({
  marker,
  selected = false,
  size = 34,
  onClick,
  renderIcon,
  mapContext,
}: MapMarkerProps) {
  if (!mapContext || marker.visible === false) return null;

  const point = mapContext.projection.coordinateToPoint(
    marker.coordinate,
  );
  const fill = statusColor(marker.status);

  return (
    <g
      transform={`translate(${point.x} ${point.y})`}
      role="button"
      tabIndex={0}
      aria-label={marker.title}
      onClick={(event) => {
        event.stopPropagation();
        onClick?.(marker);
      }}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          onClick?.(marker);
        }
      }}
      style={{ cursor: "pointer", outline: "none" }}
    >
      {selected ? (
        <circle
          r={size * 0.72}
          fill="none"
          stroke={fill}
          strokeWidth="3"
          opacity=".35"
        />
      ) : null}

      <path
        d={`M 0 ${size * 0.55}
            C ${-size * 0.08} ${size * 0.36},
              ${-size * 0.46} ${size * 0.05},
              ${-size * 0.46} ${-size * 0.24}
            A ${size * 0.46} ${size * 0.46} 0 1 1
              ${size * 0.46} ${-size * 0.24}
            C ${size * 0.46} ${size * 0.05},
              ${size * 0.08} ${size * 0.36},
              0 ${size * 0.55} Z`}
        fill={fill}
        stroke="var(--background, #fff)"
        strokeWidth="2"
        filter="url(#eleeveon-map-shadow)"
      />

      <circle
        cy={-size * 0.20}
        r={size * 0.19}
        fill="var(--background, #fff)"
      />

      <text
        x="0"
        y={-size * 0.13}
        textAnchor="middle"
        fontSize={size * 0.22}
        fontWeight="800"
        fill={fill}
        pointerEvents="none"
      >
        {renderIcon
          ? renderIcon(marker)
          : String(marker.icon ?? marker.title)
              .trim()
              .slice(0, 1)
              .toUpperCase()}
      </text>
    </g>
  );
}

export default MapMarker;
