"use client";

import {
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  clusterMarkers,
  filterMarkersByLayers,
  searchMarkers,
  splitClusters,
  viewportForMarkers,
  type MapMarker,
  type MarkerCluster,
  type MapViewport,
} from "../../lib/maps";
import {
  EntitySearchToolbar,
  PageToolbar,
} from "../shared";
import { MapCanvas } from "./core/MapCanvas";
import { MapContainer } from "./core/MapContainer";
import {
  MapProvider,
  useMapController,
} from "./core/MapProvider";
import type {
  MapLayerDefinition,
  SchoolMapData,
} from "./core/types";
import { MapViewportController } from "./core/MapViewportController";
import {
  MapMarker as MapMarkerVisual,
  MapMarkerCluster,
  MapMarkerPopup,
} from "./markers";
import {
  CircleGeofenceOverlay,
  MapHeatmapOverlay,
  RouteOverlay,
  TrackingTrailOverlay,
} from "./overlays";
import {
  MapDetailsSheet,
  MapFilterSheet,
  MapLegend,
} from "./panels";

const GHANA_VIEWPORT: MapViewport = {
  center: {
    latitude: 7.9465,
    longitude: -1.0232,
  },
  zoom: 7,
};

export interface SchoolMapProps
  extends SchoolMapData {
  layers?: readonly MapLayerDefinition[];
  initialViewport?: MapViewport;
  height?: number | string;
  cluster?: boolean;
  clusterRadiusPixels?: number;
  searchable?: boolean;
  filterable?: boolean;
  showLegend?: boolean;
  showPopup?: boolean;
  fitMarkers?: boolean;
  toolbarActions?: ReactNode;
  emptyView?: ReactNode;
  tileUrl?: string;
  tileAttribution?: string;
  onMarkerSelect?: (
    marker: MapMarker | null,
  ) => void;
  onClusterSelect?: (
    cluster: MarkerCluster | null,
  ) => void;
  onCoordinateSelect?: (coordinate: {
    latitude: number;
    longitude: number;
  }) => void;
}

function inferLayers(
  markers: readonly MapMarker[],
): MapLayerDefinition[] {
  const groups = new Map<
    string,
    MapMarker[]
  >();

  for (const marker of markers) {
    const id = marker.layerId ?? "default";
    const group = groups.get(id) ?? [];
    group.push(marker);
    groups.set(id, group);
  }

  return [...groups.entries()].map(
    ([id, group]) => ({
      id,
      label: id
        .replaceAll("_", " ")
        .replace(/\b\w/g, (character) =>
          character.toUpperCase(),
        ),
      count: group.length,
      enabled: true,
    }),
  );
}

function SchoolMapInner({
  markers = [],
  geofences = [],
  routes = [],
  trackingTrails = [],
  heatPoints = [],
  layers: providedLayers,
  height,
  cluster = true,
  clusterRadiusPixels = 56,
  searchable = true,
  filterable = true,
  showLegend = true,
  showPopup = true,
  fitMarkers = true,
  toolbarActions,
  emptyView,
  tileUrl,
  tileAttribution,
  onMarkerSelect,
  onClusterSelect,
  onCoordinateSelect,
}: Omit<SchoolMapProps, "initialViewport">) {
  const controller = useMapController();
  const [query, setQuery] = useState("");
  const [filterOpen, setFilterOpen] =
    useState(false);
  const [detailsOpen, setDetailsOpen] =
    useState(false);
  const [
    selectedCluster,
    setSelectedCluster,
  ] = useState<MarkerCluster | null>(null);

  const layers = useMemo(
    () =>
      providedLayers ??
      inferLayers(markers),
    [markers, providedLayers],
  );

  const enabledLayerIds = useMemo(() => {
    if (controller.enabledLayerIds.size) {
      return controller.enabledLayerIds;
    }

    return new Set(
      layers
        .filter(
          (layer) =>
            layer.enabled !== false,
        )
        .map((layer) => layer.id),
    );
  }, [
    controller.enabledLayerIds,
    layers,
  ]);

  const visibleMarkers = useMemo(() => {
    const searched = searchMarkers(
      markers,
      query,
    );

    return filterMarkersByLayers(
      searched,
      enabledLayerIds,
    );
  }, [
    enabledLayerIds,
    markers,
    query,
  ]);

  const clustered = useMemo(
    () =>
      splitClusters(
        clusterMarkers(
          visibleMarkers,
          controller.viewport.zoom,
          clusterRadiusPixels,
        ),
      ),
    [
      clusterRadiusPixels,
      controller.viewport.zoom,
      visibleMarkers,
    ],
  );

  const selectedMarker =
    visibleMarkers.find(
      (marker) =>
        marker.id ===
        controller.selectedMarkerId,
    ) ?? null;

  const selectMarker = (
    marker: MapMarker | null,
  ) => {
    controller.setSelectedMarkerId(
      marker?.id ?? null,
    );
    setSelectedCluster(null);
    onMarkerSelect?.(marker);
  };

  const selectCluster = (
    next: MarkerCluster | null,
  ) => {
    setSelectedCluster(next);
    controller.setSelectedMarkerId(null);
    onClusterSelect?.(next);

    if (next) {
      controller.setViewport(
        (current) => ({
          ...current,
          center: next.coordinate,
          zoom: Math.min(
            19,
            current.zoom + 2,
          ),
          bounds: next.bounds,
        }),
      );
    }
  };

  const hasMapData =
    visibleMarkers.length > 0 ||
    geofences.length > 0 ||
    routes.length > 0 ||
    trackingTrails.length > 0 ||
    heatPoints.length > 0;

  return (
    <>
      <MapViewportController
        markers={markers}
        fit={fitMarkers}
        fitKey={markers
          .map((marker) => marker.id)
          .join("|")}
      />

      <MapContainer
        height={height}
        toolbar={
          searchable ||
          filterable ||
          toolbarActions ? (
            <PageToolbar
              compact
              search={
                searchable ? (
                  <EntitySearchToolbar
                    value={query}
                    onChange={setQuery}
                    placeholder="Search map..."
                    resultCount={
                      visibleMarkers.length
                    }
                  />
                ) : undefined
              }
              filterAction={
                filterable ? (
                  <button
                    type="button"
                    onClick={() =>
                      setFilterOpen(true)
                    }
                    aria-label="Open map filters"
                    title="Filters"
                    style={{
                      width: 36,
                      height: 36,
                      border: 0,
                      borderRadius: 10,
                      background:
                        "var(--muted, rgba(148,163,184,.14))",
                      color: "inherit",
                      cursor: "pointer",
                      fontSize: 16,
                    }}
                  >
                    ≡
                  </button>
                ) : undefined
              }
              trailing={toolbarActions}
            />
          ) : undefined
        }
        footer={
          showLegend ? (
            <MapLegend
              layers={layers.map(
                (layer) => ({
                  ...layer,
                  enabled:
                    enabledLayerIds.has(
                      layer.id,
                    ),
                }),
              )}
            />
          ) : undefined
        }
      >
        {!hasMapData ? (
          emptyView ?? (
            <div
              style={{
                position: "absolute",
                zIndex: 650,
                left: 12,
                bottom: 12,
                maxWidth: 280,
                padding: "10px 12px",
                border:
                  "1px solid var(--border, rgba(148,163,184,.32))",
                borderRadius: 12,
                background:
                  "color-mix(in srgb, var(--card, #fff) 92%, transparent)",
                boxShadow:
                  "0 8px 26px rgba(15,23,42,.14)",
                color:
                  "var(--muted-foreground, #64748b)",
                fontSize: 12,
                lineHeight: 1.45,
                pointerEvents: "none",
              }}
            >
              The world map is ready. Add
              coordinates or search for a
              location to place records here.
            </div>
          )
        ) : null}

        <MapCanvas
          tileUrl={tileUrl}
          tileAttribution={
            tileAttribution
          }
          onMapClick={({
            coordinate,
          }) => {
            selectMarker(null);
            selectCluster(null);
            onCoordinateSelect?.(
              coordinate,
            );
          }}
        >
          {heatPoints.length ? (
            <MapHeatmapOverlay
              points={heatPoints}
            />
          ) : null}

          {geofences.map(
            (geofence, index) => (
              <CircleGeofenceOverlay
                key={
                  geofence.id ??
                  `geofence-${index}`
                }
                geofence={geofence}
              />
            ),
          )}

          {routes.map(
            (route, index) => (
              <RouteOverlay
                key={`route-${index}`}
                route={route}
              />
            ),
          )}

          {trackingTrails.map(
            (trail) => (
              <TrackingTrailOverlay
                key={trail.entityId}
                trail={trail}
                showPoints
              />
            ),
          )}

          {(cluster
            ? clustered.singles
            : visibleMarkers
          ).map((marker) => (
            <MapMarkerVisual
              key={marker.id}
              marker={marker}
              selected={
                marker.id ===
                controller.selectedMarkerId
              }
              onClick={selectMarker}
            />
          ))}

          {cluster
            ? clustered.groups.map(
                (markerCluster) => (
                  <MapMarkerCluster
                    key={
                      markerCluster.id
                    }
                    cluster={
                      markerCluster
                    }
                    selected={
                      markerCluster.id ===
                      selectedCluster?.id
                    }
                    onClick={
                      selectCluster
                    }
                  />
                ),
              )
            : null}

          {showPopup &&
          selectedMarker ? (
            <MapMarkerPopup
              marker={selectedMarker}
              onClose={() =>
                selectMarker(null)
              }
              onOpenDetails={() =>
                setDetailsOpen(true)
              }
            />
          ) : null}
        </MapCanvas>
      </MapContainer>

      <MapFilterSheet
        open={filterOpen}
        onOpenChange={setFilterOpen}
        layers={layers}
        enabledLayerIds={
          enabledLayerIds
        }
        onLayerEnabledChange={
          controller.setLayerEnabled
        }
        onReset={() => {
          for (const layer of layers) {
            controller.setLayerEnabled(
              layer.id,
              true,
            );
          }
        }}
      />

      <MapDetailsSheet
        open={
          detailsOpen ||
          Boolean(selectedCluster)
        }
        onOpenChange={(open) => {
          setDetailsOpen(open);

          if (!open) {
            selectCluster(null);
          }
        }}
        marker={selectedMarker}
        cluster={selectedCluster}
        onMarkerSelect={(marker) => {
          selectMarker(marker);
          setDetailsOpen(true);
        }}
      />
    </>
  );
}

export function SchoolMap({
  initialViewport,
  markers = [],
  layers,
  ...props
}: SchoolMapProps) {
  const inferred =
    layers ?? inferLayers(markers);

  const initialLayerIds = inferred
    .filter(
      (layer) =>
        layer.enabled !== false,
    )
    .map((layer) => layer.id);

  const resolvedInitialViewport =
    initialViewport ??
    (markers.length
      ? viewportForMarkers(markers)
      : GHANA_VIEWPORT);

  return (
    <MapProvider
      initialViewport={
        resolvedInitialViewport
      }
      initialLayerIds={
        initialLayerIds
      }
    >
      <SchoolMapInner
        markers={markers}
        layers={inferred}
        {...props}
      />
    </MapProvider>
  );
}

export default SchoolMap;